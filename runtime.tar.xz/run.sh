#!/bin/sh
# Klass of 99: a 32-bit Windows game, run with the trimmed Wine kept in this folder.
here=$(dirname "$(readlink -f "$0")")
# The prefix was made for a Windows user called "pi"; Wine uses that name for everyone.
export WINEPREFIX="$here/prefix" WINEUSERNAME=pi WINEDEBUG=-all
export WINEDLLOVERRIDES="mscoree,mshtml=;winemenubuilder.exe=d"
# Wake the X server first. If Wine is the first X client of an Xwayland that has
# not started yet, the game window never appears.
xdpyinfo >/dev/null 2>&1
cd "$here/game" && exec "$here/wine/bin/wine" KO99.exe
