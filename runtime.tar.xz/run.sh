#!/bin/sh
# Klass of 99: a 32-bit Windows game, run with the trimmed Wine kept in this folder.
here=$(dirname "$(readlink -f "$0")")
# The prefix was made for a Windows user called "pi"; Wine uses that name for everyone.
export WINEPREFIX="$here/prefix" WINEUSERNAME=pi WINEDEBUG=-all
export WINEDLLOVERRIDES="mscoree,mshtml=;winemenubuilder.exe=d"
# Wake the X server first. If Wine is the first X client of an Xwayland that has
# not started yet, the game window never appears.
xdpyinfo >/dev/null 2>&1
# The game takes no notice of its window's close button or of Alt+F4. Closer.exe
# starts the game and makes both leave it, the way Quit on the title screen does.
cd "$here/game" && exec "$here/wine/bin/wine" "$here/Closer.exe" KO99.exe
